
export interface User {
  id: string; // Akan menggunakan email sebagai ID
  name: string;
  email: string;
  avatarUrl: string;
}

export type GenerationMode = 'text-to-video' | 'image-to-video';
export type AspectRatio = '9:16' | '16:9';
export type Resolution = '720p' | '1080p';
export type Model = 'veo2' | 'veo3';

export interface GenerationConfig {
  prompt: string;
  mode: GenerationMode;
  aspectRatio: AspectRatio;
  resolution: Resolution;
  model: Model;
  imageFile?: File;
  imageBase64?: string;
}

export interface Project {
  id: string;
  userId: string; // Tautan ke pengguna
  prompt: string;
  thumbnailUrl: string; // Menggunakan placeholder untuk saat ini
  videoUrl: string;
  config: GenerationConfig;
  createdAt: string;
}
