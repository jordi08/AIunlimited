
import { GenerationConfig, Project } from '../types';
import { generateVideoFromGemini } from './geminiService';
import { getApiKey } from './authService';

// --- Manajemen Proyek (menyimulasikan database melalui localStorage) ---

const PROJECTS_STORAGE_KEY = 'ai-unlimited-projects';

const getProjectsFromStorage = (): Project[] => {
  try {
    const item = window.localStorage.getItem(PROJECTS_STORAGE_KEY);
    return item ? JSON.parse(item) : [];
  } catch (error) {
    console.error("Gagal mem-parsing proyek dari localStorage", error);
    return [];
  }
};

const saveProjectsToStorage = (projects: Project[]): void => {
    try {
        window.localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
    } catch (error) {
        console.error("Gagal menyimpan proyek ke localStorage", error);
    }
};

export const fetchProjects = async (userId: string): Promise<Project[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const allProjects = getProjectsFromStorage();
    return allProjects.filter(p => p.userId === userId);
};

export const fetchAllProjects = async (): Promise<Project[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return getProjectsFromStorage();
};

const addProject = async (project: Project): Promise<void> => {
    const projects = getProjectsFromStorage();
    const updatedProjects = [...projects, project];
    saveProjectsToStorage(updatedProjects);
    await new Promise(resolve => setTimeout(resolve, 300));
};

export const deleteProject = async (projectId: string): Promise<void> => {
    let projects = getProjectsFromStorage();
    projects = projects.filter(p => p.id !== projectId);
    saveProjectsToStorage(projects);
    await new Promise(resolve => setTimeout(resolve, 300));
};

export const deleteProjectsByUserId = async (userId: string): Promise<void> => {
    let projects = getProjectsFromStorage();
    projects = projects.filter(p => p.userId !== userId);
    saveProjectsToStorage(projects);
    await new Promise(resolve => setTimeout(resolve, 300));
};


// --- Pembuatan & Pengambilan Video (Sisi Klien) ---

export const getVideoBlobUrl = async (apiUrl: string): Promise<string> => {
    if (!apiUrl) {
        throw new Error("URL API video tidak valid.");
    }
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("Kunci API tidak ditemukan. Silakan atur di profil Anda.");
    }

    const videoApiUrl = `${apiUrl}&key=${apiKey}`;
    const response = await fetch(videoApiUrl);
    
    if (!response.ok) {
        throw new Error(`Gagal mengambil video. Status: ${response.status}`);
    }
    
    const videoBlob = await response.blob();
    const blobUrl = URL.createObjectURL(videoBlob);
    return blobUrl;
};

export const generateVideo = async (
    config: GenerationConfig,
    onProgress: (message: string) => void,
    userId: string
): Promise<Project> => {
    const apiKey = getApiKey();
    if (!apiKey) {
        const errorMessage = "Kunci API tidak ditemukan. Silakan atur di profil Anda.";
        onProgress(`Error: ${errorMessage}`);
        throw new Error(errorMessage);
    }

    const operation = await generateVideoFromGemini(config, apiKey, onProgress);

    if (operation.error) {
        const errorMessage = operation.error.message;
        onProgress(`Error: ${errorMessage}`);
        throw new Error(errorMessage);
    }

    onProgress("Pemrosesan video selesai!");

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;

    if (!downloadLink) {
        const errorMessage = "Tidak dapat mengambil URL video dari respons API.";
        onProgress(`Error: ${errorMessage}`);
        throw new Error(errorMessage);
    }

    const newProject: Project = {
        id: new Date().toISOString(),
        userId: userId,
        prompt: config.prompt,
        videoUrl: downloadLink,
        thumbnailUrl: 'https://picsum.photos/200/300', // placeholder
        config,
        createdAt: new Date().toISOString(),
    };

    await addProject(newProject);
    return newProject;
};
