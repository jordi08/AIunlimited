
import { User } from '../types';
import { deleteProjectsByUserId } from './apiService';

// --- Simulasi Database Pengguna ---
const USERS_STORAGE_KEY = 'ai-unlimited-users';
const CURRENT_USER_STORAGE_KEY = 'ai-unlimited-currentUser';
const ADMIN_EMAIL_STORAGE_KEY = 'ai-unlimited-admin-email';
const API_KEY_STORAGE_KEY = 'ai-unlimited-api-key';

// --- Manajemen API Key (Sisi Klien) ---
export const getApiKey = (): string | null => {
    return localStorage.getItem(API_KEY_STORAGE_KEY);
};

export const saveApiKey = (apiKey: string): void => {
    localStorage.setItem(API_KEY_STORAGE_KEY, apiKey);
};

export const clearApiKey = (): void => {
    localStorage.removeItem(API_KEY_STORAGE_KEY);
};


const getSimulatedUsers = (): User[] => {
  try {
    const users = localStorage.getItem(USERS_STORAGE_KEY);
    return users ? JSON.parse(users) : [];
  } catch (e) {
    return [];
  }
};

const saveSimulatedUsers = (users: User[]) => {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

// --- Fungsi Otentikasi ---

export const login = async (email: string): Promise<User> => {
  console.log(`Menyimulasikan login untuk: ${email}`);
  await new Promise(resolve => setTimeout(resolve, 500)); // Menyimulasikan penundaan jaringan

  const users = getSimulatedUsers();
  let user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user) {
    // Pengguna baru, buat entri
    const name = email.split('@')[0].replace(/[^a-zA-Z0-9]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    user = {
      id: email.toLowerCase(),
      name: name,
      email: email.toLowerCase(),
      avatarUrl: `https://i.pravatar.cc/150?u=${email.toLowerCase()}`,
    };

    // Aturan Admin: Pengguna pertama menjadi admin
    if (users.length === 0) {
        console.log(`Pengguna pertama ${user.email} ditetapkan sebagai admin.`);
        localStorage.setItem(ADMIN_EMAIL_STORAGE_KEY, user.email);
    }
    
    users.push(user);
    saveSimulatedUsers(users);
    console.log("Pengguna baru dibuat:", user);
  }

  // Atur pengguna saat ini di localStorage untuk persistensi sesi
  localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(user));
  return user;
};

export const logout = async (): Promise<void> => {
  console.log("Menyimulasikan logout...");
  localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
  clearApiKey();
  await new Promise(resolve => setTimeout(resolve, 200));
};

export const getCurrentUser = (): User | null => {
  try {
    const userJson = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
    return userJson ? JSON.parse(userJson) : null;
  } catch (e) {
    return null;
  }
};

// --- Fungsi Admin ---
export const isAdmin = (email: string): boolean => {
    const adminEmail = localStorage.getItem(ADMIN_EMAIL_STORAGE_KEY);
    // Juga izinkan 'admin@example.com' sebagai fallback jika tidak ada yang disetel
    return !!adminEmail && email.toLowerCase() === adminEmail.toLowerCase();
};

export const getAllUsers = (): User[] => {
  return getSimulatedUsers();
};

export const deleteUser = async (userId: string): Promise<void> => {
    // Pertama, hapus semua proyek oleh pengguna ini
    await deleteProjectsByUserId(userId);

    // Kemudian, hapus pengguna
    let users = getSimulatedUsers();
    const adminEmail = localStorage.getItem(ADMIN_EMAIL_STORAGE_KEY);

    users = users.filter(u => u.id !== userId);
    saveSimulatedUsers(users);

    console.log(`Pengguna dengan ID ${userId} dan semua proyek mereka telah dihapus.`);
    
    // Periksa apakah pengguna yang dihapus adalah admin
    if (adminEmail === userId) {
        localStorage.removeItem(ADMIN_EMAIL_STORAGE_KEY);
        console.warn("Pengguna admin telah dihapus.");
        // Jika masih ada pengguna lain, jadikan yang pertama sebagai admin baru
        if (users.length > 0) {
            localStorage.setItem(ADMIN_EMAIL_STORAGE_KEY, users[0].email);
            console.log(`Admin baru ditetapkan ke: ${users[0].email}`);
        }
    }

    await new Promise(resolve => setTimeout(resolve, 300));
};
