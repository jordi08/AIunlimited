
import { GoogleGenAI } from "@google/genai";
import { GenerationConfig } from '../types';

export const generateVideoFromGemini = async (
    config: GenerationConfig,
    apiKey: string,
    onProgress: (message: string) => void,
): Promise<any> => { // Returns the operation object
    onProgress("Menginisialisasi Klien AI...");
    const ai = new GoogleGenAI({ apiKey });
    const modelName = 'veo-2.0-generate-001';

    const videoGenConfig: {
        numberOfVideos: number;
        aspectRatio: '9:16' | '16:9';
        includeAudio?: boolean;
    } = {
        numberOfVideos: 1,
        aspectRatio: config.aspectRatio,
    };

    if (config.model === 'veo3') {
        videoGenConfig.includeAudio = true;
    }

    let operation;
    const basePayload = {
        model: modelName,
        prompt: config.prompt,
        config: videoGenConfig,
    };
    
    onProgress("Mengirim permintaan ke Google...");
    if (config.mode === 'image-to-video' && config.imageBase64 && config.imageFile) {
        // Asumsi imageFile.type adalah tipe MIME yang benar, mis. 'image/png'
        const mimeType = config.imageFile.type;
        operation = await ai.models.generateVideos({
            ...basePayload,
            image: {
                imageBytes: config.imageBase64,
                mimeType: mimeType,
            }
        });
    } else {
        operation = await ai.models.generateVideos(basePayload);
    }

    onProgress("Tugas pembuatan dimulai. Ini mungkin memakan waktu beberapa menit...");
    let pollCount = 0;
    while (!operation.done) {
        pollCount++;
        onProgress(`Menunggu video... (Pemeriksaan ${pollCount})`);
        await new Promise(resolve => setTimeout(resolve, 10000));
        
        try {
             operation = await ai.operations.getVideosOperation({ operation });
        } catch(e) {
            console.error("Polling gagal, mencoba lagi...", e);
            // Tambahkan jeda singkat sebelum mencoba lagi
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }

    return operation;
}
