
import React, { useState, useCallback, useEffect } from 'react';
import { User, GenerationConfig, Project } from '../types';
import Header from './Header';
import ConfigPanel from './ConfigPanel';
import VideoPlayer from './VideoPlayer';
import HistoryPanel from './HistoryPanel';
import { generateVideo, fetchProjects, getVideoBlobUrl } from '../services/apiService';

interface MainLayoutProps {
  user: User;
  onLogout: () => void;
  onOpenAdminDashboard: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ user, onLogout, onOpenAdminDashboard }) => {
    const [projects, setProjects] = useState<Project[]>([]);
    const [playableVideoUrl, setPlayableVideoUrl] = useState<string | null>(null);
    const [currentProject, setCurrentProject] = useState<Project | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
    
    useEffect(() => {
        const loadProjects = async () => {
            const storedProjects = await fetchProjects(user.id);
            setProjects(storedProjects);
        };
        loadProjects();
    }, [user.id]);
    
    useEffect(() => {
        // Efek ini menangani pembersihan Blob URL lama untuk mencegah kebocoran memori
        return () => {
            if (activeVideoUrl) {
                URL.revokeObjectURL(activeVideoUrl);
            }
        };
    }, [activeVideoUrl]);

    useEffect(() => {
        const loadVideo = async () => {
            if (currentProject) {
                if (activeVideoUrl) {
                    URL.revokeObjectURL(activeVideoUrl);
                }
                setPlayableVideoUrl(null);
                setIsLoading(true);
                setLoadingMessage("Memuat video...");
                try {
                    const blobUrl = await getVideoBlobUrl(currentProject.videoUrl);
                    setPlayableVideoUrl(blobUrl);
                    setActiveVideoUrl(blobUrl); // Lacak URL yang aktif untuk pembersihan
                } catch (error) {
                    console.error("Gagal memuat video:", error);
                    const errorMessage = error instanceof Error ? error.message : "Terjadi kesalahan yang tidak diketahui.";
                    setLoadingMessage(`Error: ${errorMessage}`);
                    alert(`Gagal memuat video: ${errorMessage}`);
                } finally {
                    setIsLoading(false);
                }
            }
        };
        loadVideo();
    }, [currentProject]);


    const handleGenerate = useCallback(async (config: GenerationConfig) => {
        setIsLoading(true);
        setPlayableVideoUrl(null);
        setCurrentProject(null);
        setLoadingMessage('Menyiapkan permintaan Anda...');
        try {
            // apiKey sekarang diambil secara otomatis oleh apiService
            const newProject = await generateVideo(config, setLoadingMessage, user.id);
            
            const updatedProjects = await fetchProjects(user.id);
            setProjects(updatedProjects);
            
            // Atur proyek saat ini, yang akan memicu useEffect untuk memuat video
            setCurrentProject(newProject);

        } catch (error) {
            console.error("Pembuatan video gagal:", error);
            const errorMessage = error instanceof Error ? error.message : "Terjadi kesalahan yang tidak diketahui.";
            setLoadingMessage(`Error: ${errorMessage}`);
            alert(`Pembuatan video gagal. Silakan periksa konsol untuk detailnya.\n\nPesan: ${errorMessage}`);
            setIsLoading(false); // Pastikan loading berhenti jika ada error
        }
        // setIsLoading(false) akan ditangani oleh useEffect pemuat video
    }, [user.id]);
    
    const handleSelectProject = useCallback((project: Project) => {
        setCurrentProject(project);
    }, []);

    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col">
            <Header user={user} onLogout={onLogout} onOpenAdminDashboard={onOpenAdminDashboard} />
            <main className="flex-grow p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                    <ConfigPanel 
                        onGenerate={handleGenerate} 
                        isLoading={isLoading} 
                    />
                </div>
                <div className="lg:col-span-2 flex flex-col gap-6">
                    <VideoPlayer 
                        isLoading={isLoading} 
                        loadingMessage={loadingMessage} 
                        videoUrl={playableVideoUrl}
                    />
                    <HistoryPanel 
                        projects={projects} 
                        onSelectProject={handleSelectProject} 
                        currentProjectId={currentProject?.id}
                    />
                </div>
            </main>
        </div>
    );
};

export default MainLayout;