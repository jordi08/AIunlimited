
import React, { useState, useEffect } from 'react';
import { GenerationConfig, GenerationMode, AspectRatio, Resolution, Model } from '../types';
import { UploadIcon, VideoIcon, ImageIcon, SpinnerIcon, KeyIcon, EyeIcon, EyeSlashIcon } from './icons';
import { getApiKey, saveApiKey } from '../services/authService';

interface ConfigPanelProps {
  onGenerate: (config: GenerationConfig) => void;
  isLoading: boolean;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ onGenerate, isLoading }) => {
    const [prompt, setPrompt] = useState<string>('Sebuah hologram neon kucing yang mengemudi dengan kecepatan tinggi');
    const [mode, setMode] = useState<GenerationMode>('text-to-video');
    const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
    const [resolution, setResolution] = useState<Resolution>('1080p');
    const [model, setModel] = useState<Model>('veo2');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);

    const [apiKey, setApiKey] = useState('');
    const [isKeyVisible, setIsKeyVisible] = useState(false);
    const [savedApiKey, setSavedApiKey] = useState<string | null>(getApiKey());

    useEffect(() => {
        setApiKey(savedApiKey || '');
    }, [savedApiKey]);

    const handleSaveKey = () => {
        if (apiKey.trim()) {
            saveApiKey(apiKey);
            setSavedApiKey(apiKey);
            alert('API Key berhasil disimpan!');
        } else {
            alert('API Key tidak boleh kosong.');
        }
    };

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            setImageFile(file);
            setImagePreview(URL.createObjectURL(file));
        }
    };
    
    const fileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                const result = (reader.result as string).split(',')[1];
                resolve(result);
            };
            reader.onerror = error => reject(error);
        });
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim()) {
            alert('Silakan masukkan prompt.');
            return;
        }
        if (mode === 'image-to-video' && !imageFile) {
            alert('Silakan unggah gambar untuk mode gambar-ke-video.');
            return;
        }
        
        let imageBase64: string | undefined = undefined;
        if(mode === 'image-to-video' && imageFile) {
            imageBase64 = await fileToBase64(imageFile);
        }
        
        onGenerate({ prompt, mode, aspectRatio, resolution, model, imageFile: imageFile || undefined, imageBase64 });
    };

    const renderFileUpload = () => (
        <div className="mt-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">Gambar Referensi</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
                <div className="space-y-1 text-center">
                    {imagePreview ? (
                        <img src={imagePreview} alt="Preview" className="mx-auto h-24 w-auto rounded-md" />
                    ) : (
                        <UploadIcon className="mx-auto h-12 w-12 text-gray-500" />
                    )}
                    <div className="flex text-sm text-gray-400">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-800 rounded-md font-medium text-green-400 hover:text-green-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-gray-900 focus-within:ring-green-500">
                            <span>Unggah file</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleImageChange} accept="image/png, image/jpeg, image/webp" />
                        </label>
                        <p className="pl-1">atau seret dan lepas</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, WEBP hingga 10MB</p>
                    {imageFile && <p className="text-xs text-green-400 pt-2">{imageFile.name}</p>}
                </div>
            </div>
        </div>
    );
    
    const OptionButton = <T extends string,>({ value, selectedValue, setSelectedValue, children }: {value: T, selectedValue: T, setSelectedValue: React.Dispatch<React.SetStateAction<T>>, children: React.ReactNode}) => {
        const isSelected = value === selectedValue;
        return (
            <button
                type="button"
                onClick={() => setSelectedValue(value)}
                className={`flex-1 p-3 rounded-md text-sm font-semibold flex items-center justify-center space-x-2 transition-all duration-200 ${isSelected ? 'bg-green-500 text-white shadow-lg' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            >
                {children}
            </button>
        );
    };

    return (
        <form onSubmit={handleSubmit} className="p-6 bg-gray-800 rounded-lg space-y-6 h-full flex flex-col">
            <div>
                <label htmlFor="api-key" className="block text-sm font-medium text-gray-300 mb-2">Gemini API Key</label>
                <div className="flex items-center space-x-2">
                    <div className="relative flex-grow">
                        <KeyIcon className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                        <input
                            id="api-key"
                            type={isKeyVisible ? 'text' : 'password'}
                            className="w-full bg-gray-900 border border-gray-700 rounded-md p-3 pl-10 text-white focus:ring-green-500 focus:border-green-500 transition"
                            placeholder="Masukkan API Key Anda"
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                        />
                        <button type="button" onClick={() => setIsKeyVisible(!isKeyVisible)} className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-green-400" aria-label={isKeyVisible ? "Sembunyikan kunci" : "Tampilkan kunci"}>
                            {isKeyVisible ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                        </button>
                    </div>
                    <button
                        type="button"
                        onClick={handleSaveKey}
                        className="px-4 py-3 bg-gray-600 text-white font-semibold rounded-lg hover:bg-gray-500 transition-colors flex-shrink-0"
                    >
                        Simpan
                    </button>
                </div>
                 <p className="text-xs text-gray-500 mt-2">
                    Kunci Anda disimpan di browser.
                    <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-green-400 hover:underline ml-1">
                        Dapatkan API Key
                    </a>
                </p>
            </div>
            
            <hr className="border-gray-700" /> 
            
            <div>
                <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">Prompt</label>
                <textarea
                    id="prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={4}
                    className="w-full bg-gray-900 border border-gray-700 rounded-md p-3 text-white focus:ring-green-500 focus:border-green-500 transition"
                    placeholder="cth., Seorang astronot menunggang kuda di Mars"
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Mode</label>
                <div className="flex space-x-2 bg-gray-800 p-1 rounded-lg">
                    <OptionButton value="text-to-video" selectedValue={mode} setSelectedValue={setMode}>
                        <VideoIcon className="w-5 h-5"/>
                        <span>Teks ke Video</span>
                    </OptionButton>
                     <OptionButton value="image-to-video" selectedValue={mode} setSelectedValue={setMode}>
                         <ImageIcon className="w-5 h-5"/>
                         <span>Gambar ke Video</span>
                    </OptionButton>
                </div>
                {mode === 'image-to-video' && renderFileUpload()}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Rasio Aspek</label>
                    <select value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value as AspectRatio)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white focus:ring-green-500 focus:border-green-500">
                        <option value="16:9">16:9 (Lanskap)</option>
                        <option value="9:16">9:16 (Potret)</option>
                    </select>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Resolusi</label>
                    <select value={resolution} onChange={(e) => setResolution(e.target.value as Resolution)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white focus:ring-green-500 focus:border-green-500">
                        <option value="1080p">1080p</option>
                        <option value="720p">720p</option>
                    </select>
                     <p className="text-xs text-gray-500 mt-1">Catatan: Tidak semua model mendukung ini.</p>
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
                <select value={model} onChange={(e) => setModel(e.target.value as Model)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2 text-white focus:ring-green-500 focus:border-green-500">
                    <option value="veo2">Veo 2</option>
                    <option value="veo3">Veo 3 (Eksperimental)</option>
                </select>
                {model === 'veo3' && (
                    <p className="text-xs text-green-400 mt-1">
                        Catatan: Model ini akan menghasilkan audio bersama dengan video.
                    </p>
                )}
            </div>

            <div className="flex-grow"></div>

            <div className="mt-4">
                <button
                    type="submit"
                    disabled={isLoading || !savedApiKey}
                    className="w-full py-3 px-4 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center space-x-2"
                >
                    {isLoading ? <SpinnerIcon className="w-5 h-5 animate-spin"/> : <VideoIcon className="w-5 h-5" />}
                    <span>{isLoading ? 'Menghasilkan...' : 'Hasilkan Video'}</span>
                </button>
                {!savedApiKey && (
                    <p className="text-xs text-center text-yellow-400 mt-2">
                        Silakan simpan API Key Anda untuk mengaktifkan pembuatan video.
                    </p>
                )}
            </div>
        </form>
    );
};

export default ConfigPanel;