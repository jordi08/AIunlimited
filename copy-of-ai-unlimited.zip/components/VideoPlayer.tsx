import React, { useState, useEffect } from 'react';
import { SpinnerIcon, VideoIcon } from './icons';

interface VideoPlayerProps {
    isLoading: boolean;
    loadingMessage: string;
    videoUrl: string | null;
}

const loadingMessages = [
    "Memanaskan artis AI...",
    "Mencampur cat digital...",
    "Mengarahkan aktor virtual...",
    "Merender beberapa frame pertama...",
    "Ini memakan waktu sedikit lebih lama dari biasanya...",
    "Menyelesaikan potongan akhir...",
    "Hampir sampai, sebentar lagi."
];

const VideoPlayer: React.FC<VideoPlayerProps> = ({ isLoading, loadingMessage, videoUrl }) => {
    const [displayMessage, setDisplayMessage] = useState(loadingMessages[0]);

    useEffect(() => {
        // Fix: Use ReturnType<typeof setInterval> to get the correct type for the interval ID, which works in both browser and Node environments.
        let interval: ReturnType<typeof setInterval> | null = null;
        if (isLoading) {
            let index = 0;
            interval = setInterval(() => {
                index = (index + 1) % loadingMessages.length;
                setDisplayMessage(loadingMessages[index]);
            }, 5000);
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    }, [isLoading]);


    return (
        <div className="w-full h-full bg-gray-900 rounded-lg flex items-center justify-center aspect-video border border-gray-700 overflow-hidden">
            {isLoading ? (
                <div className="text-center text-gray-300 p-4">
                    <SpinnerIcon className="w-12 h-12 text-green-400 animate-spin mx-auto mb-4" />
                    <p className="text-lg font-semibold mb-2">{loadingMessage}</p>
                    <p className="text-sm text-gray-400 animate-pulse">{displayMessage}</p>
                </div>
            ) : videoUrl ? (
                <video src={videoUrl} controls autoPlay loop className="w-full h-full object-contain"></video>
            ) : (
                <div className="text-center text-gray-500 p-4">
                    <VideoIcon className="w-24 h-24 mx-auto mb-4" />
                    <h2 className="text-xl font-semibold text-gray-300">Video yang Anda Hasilkan Akan Muncul Di Sini</h2>
                    <p className="mt-2">Konfigurasikan pengaturan Anda dan klik "Hasilkan Video" untuk memulai.</p>
                </div>
            )}
        </div>
    );
};

export default VideoPlayer;