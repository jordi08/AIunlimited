import React, { useState, useEffect } from 'react';
import { User, Project } from '../types';
import { getAllUsers, deleteUser } from '../services/authService';
import { fetchAllProjects, getVideoBlobUrl, deleteProject } from '../services/apiService';
import { SpinnerIcon, DownloadIcon, TrashIcon } from './icons';
import { VideoThumbnail } from './VideoThumbnail';

interface AdminDashboardProps {
  onClose: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [projects, setProjects] = useState<Project[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [downloadingProjectId, setDownloadingProjectId] = useState<string | null>(null);
    const [isDeleting, setIsDeleting] = useState<string | null>(null);

    const fetchData = async () => {
        setIsLoading(true);
        const allUsers = getAllUsers();
        const allProjects = await fetchAllProjects();
        setUsers(allUsers);
        setProjects(allProjects);
        setIsLoading(false);
    };

    useEffect(() => {
        fetchData();
    }, []);

    const getProjectCountForUser = (userId: string) => {
        return projects.filter(p => p.userId === userId).length;
    };
    
    const handleDownload = async (project: Project) => {
        if (downloadingProjectId || isDeleting) return;
        setDownloadingProjectId(project.id);
        try {
            const blobUrl = await getVideoBlobUrl(project.videoUrl);
            const link = document.createElement('a');
            link.href = blobUrl;
            const safePrompt = project.prompt.substring(0, 30).replace(/[^a-z0-9]/gi, '_').toLowerCase();
            link.download = `${safePrompt}_${project.id.substring(0, 8)}.mp4`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl);
        } catch (error) {
            console.error("Download failed:", error);
            const errorMessage = error instanceof Error ? error.message : "Terjadi kesalahan yang tidak diketahui.";
            alert(`Gagal mengunduh video: ${errorMessage}`);
        } finally {
            setDownloadingProjectId(null);
        }
    };

    const handleDeleteProject = async (projectId: string) => {
        if (isDeleting) return;
        if (window.confirm('Apakah Anda yakin ingin menghapus proyek ini secara permanen?')) {
            setIsDeleting(projectId);
            try {
                await deleteProject(projectId);
                setProjects(prev => prev.filter(p => p.id !== projectId));
            } catch (error) {
                console.error("Gagal menghapus proyek:", error);
                alert("Gagal menghapus proyek.");
            } finally {
                setIsDeleting(null);
            }
        }
    };

    const handleDeleteUser = async (user: User) => {
        if (isDeleting) return;
        if (window.confirm(`PERINGATAN: Menghapus pengguna '${user.name}' juga akan menghapus SEMUA video mereka secara permanen. Apakah Anda yakin?`)) {
            setIsDeleting(user.id);
            try {
                await deleteUser(user.id);
                await fetchData(); // Muat ulang semua data
            } catch (error) {
                console.error("Gagal menghapus pengguna:", error);
                alert("Gagal menghapus pengguna.");
            } finally {
                setIsDeleting(null);
            }
        }
    };


    return (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-80 flex items-center justify-center z-50 p-4">
            <div className="w-full max-w-5xl bg-gray-800 border border-gray-700 rounded-lg shadow-2xl flex flex-col" style={{maxHeight: '90vh'}}>
                <div className="p-4 border-b border-gray-700 flex justify-between items-center flex-shrink-0">
                    <h2 className="text-xl font-bold text-green-400">Dasbor Admin</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white text-3xl leading-none">&times;</button>
                </div>

                {isLoading ? (
                    <div className="flex-grow flex items-center justify-center p-8">
                        <SpinnerIcon className="w-12 h-12 text-green-400 animate-spin" />
                    </div>
                ) : (
                    <div className="p-6 overflow-y-auto">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div className="bg-gray-900 p-4 rounded-lg text-center">
                                <p className="text-sm text-gray-400">Total Pengguna</p>
                                <p className="text-3xl font-bold text-white">{users.length}</p>
                            </div>
                            <div className="bg-gray-900 p-4 rounded-lg text-center">
                                <p className="text-sm text-gray-400">Total Video Dihasilkan</p>
                                <p className="text-3xl font-bold text-white">{projects.length}</p>
                            </div>
                        </div>

                        <h3 className="text-lg font-semibold text-white mb-4">Pengguna & Aktivitas</h3>
                        <div className="bg-gray-900 rounded-lg overflow-hidden mb-8">
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left text-gray-400">
                                    <thead className="text-xs text-gray-300 uppercase bg-gray-700">
                                        <tr>
                                            <th scope="col" className="px-6 py-3">Email</th>
                                            <th scope="col" className="px-6 py-3">Nama</th>
                                            <th scope="col" className="px-6 py-3 text-right">Video</th>
                                            <th scope="col" className="px-6 py-3 text-right">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {users.map(user => (
                                            <tr key={user.id} className="border-b border-gray-700 hover:bg-gray-800">
                                                <td className="px-6 py-4 font-medium text-white whitespace-nowrap">{user.email}</td>
                                                <td className="px-6 py-4">{user.name}</td>
                                                <td className="px-6 py-4 text-right font-bold text-green-400">{getProjectCountForUser(user.id)}</td>
                                                <td className="px-6 py-4 text-right">
                                                    <button
                                                        onClick={() => handleDeleteUser(user)}
                                                        disabled={!!isDeleting}
                                                        className="p-1 text-red-500 hover:text-red-400 disabled:text-gray-500 disabled:cursor-wait rounded-full hover:bg-gray-700"
                                                        title="Hapus Pengguna"
                                                    >
                                                        {isDeleting === user.id ? <SpinnerIcon className="w-5 h-5 animate-spin"/> : <TrashIcon className="w-5 h-5" />}
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                             {users.length === 0 && <p className="text-center p-4 text-gray-500">Belum ada pengguna yang terdaftar.</p>}
                        </div>

                        <h3 className="text-lg font-semibold text-white mb-4">Semua Video yang Dihasilkan</h3>
                        <div className="bg-gray-900 rounded-lg overflow-hidden">
                             <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left text-gray-400">
                                    <thead className="text-xs text-gray-300 uppercase bg-gray-700">
                                        <tr>
                                            <th scope="col" className="px-4 py-3">Thumbnail</th>
                                            <th scope="col" className="px-4 py-3">Prompt</th>
                                            <th scope="col" className="px-4 py-3">Pengguna</th>
                                            <th scope="col" className="px-4 py-3">Tanggal Dibuat</th>
                                            <th scope="col" className="px-4 py-3">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {[...projects].reverse().map(project => {
                                            const user = users.find(u => u.id === project.userId);
                                            return (
                                                <tr key={project.id} className="border-b border-gray-700 hover:bg-gray-800 align-top">
                                                    <td className="p-2">
                                                        <VideoThumbnail videoUrl={project.videoUrl} className="w-24 h-16 rounded bg-black object-cover" />
                                                    </td>
                                                    <td className="px-4 py-4 font-medium text-white" style={{ maxWidth: '300px' }}><p className="truncate">{project.prompt}</p></td>
                                                    <td className="px-4 py-4 text-xs truncate">{user?.email || 'Tidak dikenal'}</td>
                                                    <td className="px-4 py-4 text-xs whitespace-nowrap">{new Date(project.createdAt).toLocaleString()}</td>
                                                    <td className="px-4 py-4">
                                                        <div className="flex items-center space-x-2">
                                                            <button 
                                                                onClick={() => handleDownload(project)}
                                                                disabled={!!downloadingProjectId || !!isDeleting}
                                                                className="flex items-center justify-center px-3 py-1.5 text-xs font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-wait transition-colors"
                                                            >
                                                                {downloadingProjectId === project.id ? (
                                                                    <SpinnerIcon className="w-4 h-4 animate-spin"/>
                                                                ) : (
                                                                    <DownloadIcon className="w-4 h-4"/>
                                                                )}
                                                                <span className="ml-2 hidden sm:inline">{downloadingProjectId === project.id ? 'Mengunduh...' : 'Unduh'}</span>
                                                            </button>
                                                            <button
                                                                onClick={() => handleDeleteProject(project.id)}
                                                                disabled={!!downloadingProjectId || !!isDeleting}
                                                                className="flex items-center justify-center p-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:bg-gray-500 disabled:cursor-wait transition-colors"
                                                                title="Hapus Proyek"
                                                            >
                                                                {isDeleting === project.id ? (
                                                                    <SpinnerIcon className="w-4 h-4 animate-spin"/>
                                                                ) : (
                                                                    <TrashIcon className="w-4 h-4"/>
                                                                )}
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            )
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            {projects.length === 0 && <p className="text-center p-4 text-gray-500">Belum ada video yang dihasilkan.</p>}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;