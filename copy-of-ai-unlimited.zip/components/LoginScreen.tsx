
import React, { useState } from 'react';
import { GoogleIcon } from './icons';

interface LoginScreenProps {
  onLogin: (email: string) => Promise<void>;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');

  const handleLoginClick = async () => {
    if (!email.trim() || !email.includes('@')) {
        alert('Silakan masukkan alamat email yang valid.');
        return;
    }
    setIsLoading(true);
    await onLogin(email);
    // Komponen akan unmount pada login yang berhasil, jadi tidak perlu mengatur isLoading ke false.
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="w-full max-w-md p-8 space-y-8 bg-gray-800 border border-gray-700 rounded-lg shadow-2xl">
        <div className="text-center">
            <h1 className="text-4xl font-bold text-green-400">AI UNLIMITED</h1>
            <p className="mt-2 text-gray-400">Masuk atau daftar untuk melanjutkan</p>
        </div>
        <div className="mt-8 space-y-6">
             <div>
              <label htmlFor="email-address" className="sr-only">Alamat email</label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="w-full px-3 py-2 text-white bg-gray-900 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 placeholder-gray-500"
                placeholder="Masukkan email Anda"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLoginClick()}
              />
            </div>
            <button
                onClick={handleLoginClick}
                disabled={isLoading || !email}
                className="group w-full flex items-center justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-green-500 transition-colors duration-300 disabled:bg-gray-500 disabled:cursor-wait"
            >
                {isLoading ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span>Memproses...</span>
                    </>
                ) : (
                   <>
                        <GoogleIcon className="w-5 h-5 mr-3" />
                        <span>Lanjutkan dengan Email</span>
                   </>
                )}
            </button>
             <p className="text-xs text-center text-gray-500">
                Login disimulasikan. Pengguna pertama yang mendaftar akan menjadi admin.
            </p>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;