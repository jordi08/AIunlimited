
import React, { useState, useEffect } from 'react';
import { getVideoBlobUrl } from '../services/apiService';
import { SpinnerIcon } from './icons';

interface VideoThumbnailProps {
  videoUrl: string; // Ini adalah URL API, bukan URL yang dapat diputar
  className?: string;
}

export const VideoThumbnail: React.FC<VideoThumbnailProps> = ({ videoUrl, className }) => {
    const [playableUrl, setPlayableUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let isMounted = true;
        let objectUrl: string | null = null;

        const loadVideo = async () => {
            try {
                const blobUrl = await getVideoBlobUrl(videoUrl);
                if (isMounted) {
                    objectUrl = blobUrl;
                    setPlayableUrl(blobUrl);
                }
            } catch (err) {
                console.error("Gagal memuat thumbnail video:", err);
                if (isMounted) {
                    setError("Gagal memuat");
                }
            }
        };

        loadVideo();

        return () => {
            isMounted = false;
            if (objectUrl) {
                URL.revokeObjectURL(objectUrl);
            }
        };
    }, [videoUrl]);

    if (error) {
        return (
            <div className={`${className} flex items-center justify-center bg-red-900/50 text-white text-xs`}>
                Error
            </div>
        );
    }

    if (!playableUrl) {
        return (
             <div className={`${className} flex items-center justify-center`}>
                <SpinnerIcon className="w-6 h-6 text-gray-400 animate-spin" />
            </div>
        );
    }

    return (
        <video 
            src={playableUrl}
            className={className}
            muted
            preload="metadata"
            onLoadedMetadata={(e) => { e.currentTarget.currentTime = 1; }} // Tampilkan frame pertama sebagai thumbnail
        />
    );
};
