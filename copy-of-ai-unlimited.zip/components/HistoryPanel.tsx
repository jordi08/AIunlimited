
import React from 'react';
import { Project } from '../types';
import { VideoThumbnail } from './VideoThumbnail';

interface HistoryPanelProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
  currentProjectId?: string;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ projects, onSelectProject, currentProjectId }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-4 h-full flex flex-col">
      <h2 className="text-lg font-semibold text-white mb-4 border-b border-gray-700 pb-2">Riwayat Proyek</h2>
      {projects.length === 0 ? (
        <div className="flex-grow flex items-center justify-center text-center text-gray-500">
            <p>Video yang Anda hasilkan akan disimpan di sini.</p>
        </div>
      ) : (
        <div className="space-y-3 overflow-y-auto pr-2">
            {[...projects].reverse().map(project => (
                <button 
                    key={project.id}
                    onClick={() => onSelectProject(project)}
                    className={`w-full flex items-center p-2 rounded-lg transition-all duration-200 text-left ${currentProjectId === project.id ? 'bg-green-600/50' : 'bg-gray-700 hover:bg-gray-600'}`}
                >
                    <VideoThumbnail 
                        videoUrl={project.videoUrl}
                        className="w-16 h-10 rounded-md bg-black object-cover mr-4 flex-shrink-0"
                    />
                    <div className="overflow-hidden">
                        <p className="text-sm font-medium text-white truncate">{project.prompt}</p>
                        <p className="text-xs text-gray-400">{new Date(project.createdAt).toLocaleString()}</p>
                    </div>
                </button>
            ))}
        </div>
      )}
    </div>
  );
};

export default HistoryPanel;
