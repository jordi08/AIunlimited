import React, { useState } from 'react';
import { EyeIcon, EyeSlashIcon } from './icons';

interface ApiKeyModalProps {
  onSave: (apiKey: string) => void;
}

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ onSave }) => {
  const [key, setKey] = useState('');
  const [isKeyVisible, setIsKeyVisible] = useState(false);

  const handleSave = () => {
    if (key.trim()) {
      onSave(key);
    } else {
      alert('API Key tidak boleh kosong.');
    }
  };

  const toggleVisibility = () => {
    setIsKeyVisible(!isKeyVisible);
  };

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-80 flex items-center justify-center z-50">
      <div className="w-full max-w-md p-8 space-y-6 bg-gray-800 border border-gray-700 rounded-lg shadow-2xl">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-green-400">Masukkan Gemini API Key Anda</h2>
          <p className="mt-2 text-gray-400">
            Aplikasi ini memerlukan API Key Anda sendiri untuk berinteraksi dengan Google Gemini API.
          </p>
        </div>
        
        <div className="relative">
          <label htmlFor="api-key" className="sr-only">
            API Key
          </label>
          <input
            id="api-key"
            name="api-key"
            type={isKeyVisible ? 'text' : 'password'}
            autoComplete="off"
            required
            className="w-full px-3 py-2 pr-10 text-white bg-gray-900 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
            placeholder="Masukkan API Key Anda di sini"
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />
           <button
              type="button"
              onClick={toggleVisibility}
              className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-400 hover:text-green-400"
              aria-label={isKeyVisible ? "Sembunyikan kunci API" : "Tampilkan kunci API"}
            >
              {isKeyVisible ? (
                  <EyeSlashIcon className="w-5 h-5" />
              ) : (
                  <EyeIcon className="w-5 h-5" />
              )}
          </button>
        </div>
        
        <div className="flex flex-col space-y-4">
          <button
            onClick={handleSave}
            className="w-full py-3 px-4 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 disabled:bg-gray-600 transition-colors"
          >
            Simpan dan Lanjutkan
          </button>
          <a
            href="https://aistudio.google.com/app/apikey"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-center text-green-400 hover:underline"
          >
            Dapatkan API Key dari Google AI Studio
          </a>
        </div>
        
        <p className="text-xs text-center text-gray-500">
          Kunci Anda disimpan dengan aman di browser Anda dan tidak pernah dikirim ke server kami.
        </p>
      </div>
    </div>
  );
};

export default ApiKeyModal;