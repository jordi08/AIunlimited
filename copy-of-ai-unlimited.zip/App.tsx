
import React, { useState, useCallback, useEffect } from 'react';
import LoginScreen from './components/LoginScreen';
import MainLayout from './components/MainLayout';
import AdminDashboard from './components/AdminDashboard';
import { User } from './types';
import { login, logout, getCurrentUser, clearApiKey } from './services/authService';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdminDashboardOpen, setAdminDashboardOpen] = useState(false);
  const [isAppReady, setIsAppReady] = useState(false);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) {
        setUser(currentUser);
    }
    setIsAppReady(true);
  }, []);
  
  const handleLogin = useCallback(async (email: string) => {
    try {
        const loggedInUser = await login(email);
        setUser(loggedInUser);
        // Logika API key sekarang ditangani di dalam MainLayout/ConfigPanel
    } catch (error) {
        console.error("Login failed:", error);
        alert("Login gagal. Silakan coba lagi.");
    }
  }, []);

  const handleLogout = useCallback(async () => {
    try {
        await logout();
        setUser(null);
        // Kunci API dihapus saat logout oleh fungsi logout itu sendiri
    } catch (error) {
        console.error("Logout failed:", error);
        alert("Logout gagal. Silakan coba lagi.");
    }
  }, []);

  if (!isAppReady) {
    return null; // Atau tampilkan layar pemuatan global
  }

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <>
        <MainLayout 
            user={user} 
            onLogout={handleLogout} 
            onOpenAdminDashboard={() => setAdminDashboardOpen(true)}
         />
        {isAdminDashboardOpen && <AdminDashboard onClose={() => setAdminDashboardOpen(false)} />}
    </>
    );
};

export default App;